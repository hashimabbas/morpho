import { SVGAttributes } from 'react';

export default function AppLogoIcon(props: SVGAttributes<SVGElement>) {
    return (

        <img src="/new_logo_transp.png" alt="App Logo" />
    );
}
